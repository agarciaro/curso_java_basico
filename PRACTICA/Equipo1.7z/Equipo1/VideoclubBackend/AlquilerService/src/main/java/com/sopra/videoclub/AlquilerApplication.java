package com.sopra.videoclub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlquilerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlquilerApplication.class, args);

	}

}
